<template>
<div class="contenedor">
    <principal></principal>
    <div class="contenido">
        <router-view></router-view>
    </div>
</div>
</template>
    
<script setup>
import principal from '../components/principal.vue';
</script>
    
<style>
.contenedor{
    display: flex;
}
.contenido{
    flex: 1;
    padding: 20px;
}
</style>