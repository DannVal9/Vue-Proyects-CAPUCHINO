import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    /*{
      path: '/',
      name: 'home',
      component: HomeView
    },*/
    {
      path: '/Primer',
      name: 'Primer',
      component: () => import('../components/Primer.vue')
    },
    {
      path: '/Com',
      name: 'Componente1',
      component: () => import('../components/Com.vue')
    },
    {
      path: '/ComDos',
      name: 'Componente2',
      component: () => import('../components/ComDos.vue')
    }
  ]
})

export default router
