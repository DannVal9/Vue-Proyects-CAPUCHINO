<template>
    <div>
      <p>Contador: {{ count }}</p>
      <button @click="increment">Incrementar</button>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  
  const count = ref(0);
  const increment = () => {
    count.value++;
  };
  </script>
  
  <style scoped>
  p {
    font-size: 18px;
    color: white;
  }
  
  button {
    border-radius: 10px;
    padding: 10px 20px;
    font-size: 16px;
    background-color: #007bff;
    color: white;
    border: none;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  </style>