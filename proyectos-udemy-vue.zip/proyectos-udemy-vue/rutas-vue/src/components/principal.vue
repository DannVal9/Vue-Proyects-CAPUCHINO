<template>
<div class="principal">
<h2>Menú principal</h2>
<ul>
<li><RouterLink to="/Primer"> Primer Punto</RouterLink></li>
<li><router-link to="/Com"> Parte 1 del segundo punto</router-link></li>
<li><router-link to="/ComDos">Parte 2 del segundo punto</router-link></li>
</ul>
</div>
</template>

<script setup>

</script>

<style>
.principal{
    width: 200px;
    background-color: #f0f0f0;
    padding: 20px;
}
</style>