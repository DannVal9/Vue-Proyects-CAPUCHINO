<template>
<MainView></MainView>
</template>

<script setup>
import MainView from './views/MainView.vue';
</script>

<style scoped>

</style>
