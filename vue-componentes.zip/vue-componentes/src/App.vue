<script setup>
import Com from './Com.vue'
import Com2 from './ComDos.vue'

const saveValue = value => {
  alert(value)
}
</script>

<template>
  <h1>Ejemplos Componentes:</h1>
  <Com type="email" @update="saveValue"/>
  <Com2/>
</template>